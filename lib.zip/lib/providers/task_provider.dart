import 'package:flutter/foundation.dart';
import '../model/task_model.dart';
import '../webServices/ApiService.dart';

class QuestionProvider extends ChangeNotifier {
  List<Unit> units = [];
  bool isLoading = true;
  int currentUnitIndex = 0;
  int correctAnswersCount = 0;
  bool isHintDialogVisible = false; // Track hint dialog visibility

  Future<void> fetchTasksFromQRCode(String qrCodeUrl) async {
    try {
      final fetchedGame = await ApiService.fetchGameData(qrCodeUrl);
      units = fetchedGame.units;
      isLoading = false;
      correctAnswersCount = 0; // Reset correct answers count
      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('Failed to load tasks: $e');
      }
      isLoading = false;
      notifyListeners();
    }
  }

void goToNextUnit() {
  if (currentUnitIndex < units.length - 1) {
    currentUnitIndex++;
    // Ensure hint dialog visibility is reset
    isHintDialogVisible = false;
    notifyListeners();
  }
}


  void incrementCorrectAnswers() {
    correctAnswersCount++;
    notifyListeners();
  }

  bool isLastUnit() {
    return currentUnitIndex == units.length - 1;
  }

  void resetGame() {
    currentUnitIndex = 0;
    correctAnswersCount = 0;
    isHintDialogVisible = false; // Reset dialog visibility on game reset
    notifyListeners();
  }

  void showHintDialog() {
    isHintDialogVisible = true;
    notifyListeners();
  }

  void hideHintDialog() {
    isHintDialogVisible = false;
    notifyListeners();
  }

  Unit get currentUnit => units[currentUnitIndex];
  Task get currentTask => currentUnit.taskDTO;
  String get currentHint => currentUnit.hint;
}
