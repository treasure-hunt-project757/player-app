import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'providers/task_provider.dart';
import 'theme/app_theme.dart';
import 'view/screens/init_screen.dart';
List<CameraDescription> cameras = [];
void main() async {
  // Declare this at the top of your main.dart


  WidgetsFlutterBinding.ensureInitialized();
  //final List<CameraDescription> cameras = await availableCameras();
  cameras = await availableCameras();
  for (var camera in cameras) {
    if (kDebugMode) {
      print(camera.lensDirection);
    }
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(providers:[ChangeNotifierProvider(
      create: (context) => QuestionProvider()) ],
    child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Find the treasure',
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('ar'),
          Locale('he'),
        ],
        theme: MyAppTheme.buildTheme(),
        home: const InitScreen()));
  }
}
