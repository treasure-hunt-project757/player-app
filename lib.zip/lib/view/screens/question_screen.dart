// import 'package:flutter/material.dart';

// import '../widgets/question.dart';
// import 'template_game.dart';

// class QuestionScreen extends StatefulWidget {
//   const QuestionScreen({super.key});

//   @override
//   State<QuestionScreen> createState() => _QuestionScreenState();
// }

// class _QuestionScreenState extends State<QuestionScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Stack(
//         fit: StackFit.expand,
//         children: [
//           const TemplateGameScreen(),
//           const Positioned(
//             child: Center(
//               child: Question(),
//             ),
//           ),
//           Positioned(
//             bottom: -100,
//             right: 30,
//             child: Image.asset(
//               'assets/images/avatar_pirate.png',
//               width: 200,
//               height: 500,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
