import 'package:flutter/material.dart';
import 'dart:async';

import '../screens/hello_page.dart';

class FinalScreen extends StatefulWidget {
  final int correctAnswersCount;
  final int totalQuestions;

  const FinalScreen({Key? key, required this.correctAnswersCount, required this.totalQuestions}) : super(key: key);

  @override
  _FinalScreenState createState() => _FinalScreenState();
}

class _FinalScreenState extends State<FinalScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 1), // Faster animation
      vsync: this,
    )..repeat(reverse: true);

    _opacityAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(_controller); // More visible
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F2DE), // Use a light background color similar to the one in the image
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // The wooden sign background
            Container(
              padding: const EdgeInsets.all(20.0),
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/pause_board.png'), // Replace with your image path
                  fit: BoxFit.cover,
                ),
              ),
              child: const Text(
                'מצאת המטמון!\nנראה אותך במשחק הבא!',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.brown,
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),
            // Display the correct answers count
            Text(
              'נכון: ${widget.correctAnswersCount} מתוך ${widget.totalQuestions}',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.brown, // Match this color with the theme
              ),
            ),
            const SizedBox(height: 20),
            // The "Exit" button with custom background
            GestureDetector(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const HelloPage()),
                );
              },
              child: Container(
                width: 200,
                height: 50,
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/button.png'), // Replace with your image path
                    fit: BoxFit.cover,
                  ),
                ),
                child: const Center(
                  child: Text(
                    'יציאה',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Display the GIF instead of the video
            Stack(
              alignment: Alignment.center,
              children: [
                Image.asset(
                  'assets/images/treasure-unscreen1.gif', // Replace with your GIF path
                  width: 200,
                  height: 200,
                ),
                Positioned(
                  top: 30,
                  left: 50,
                  child: FadeTransition(
                    opacity: _opacityAnimation,
                    child: Image.asset(
                      'assets/images/sparkle.png', // Replace with your sparkle image path
                      width: 50,
                      height: 50,
                    ),
                  ),
                ),
                Positioned(
                  top: 50,
                  right: 50,
                  child: FadeTransition(
                    opacity: _opacityAnimation,
                    child: Image.asset(
                      'assets/images/sparkle.png', // Replace with your sparkle image path
                      width: 60,
                      height: 60,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 30,
                  left: 70,
                  child: FadeTransition(
                    opacity: _opacityAnimation,
                    child: Image.asset(
                      'assets/images/sparkle.png', // Replace with your sparkle image path
                      width: 40,
                      height: 40,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 50,
                  right: 70,
                  child: FadeTransition(
                    opacity: _opacityAnimation,
                    child: Image.asset(
                      'assets/images/sparkle.png', // Replace with your sparkle image path
                      width: 45,
                      height: 45,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
