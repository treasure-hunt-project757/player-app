import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../model/task_model.dart';
import '../../providers/task_provider.dart';
import '../screens/template_game.dart';
import 'FinalScreen.dart';
import 'MediaWidget.dart';

class Question extends StatefulWidget {
  const Question({super.key});

  @override
  State<Question> createState() => _QuestionState();
}

class _QuestionState extends State<Question> {
  String selectedAnswer = '';
  bool answerSelected = false;
  String correctAnswer = '';
  bool isHintDialogVisible = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final questionProvider =
          Provider.of<QuestionProvider>(context, listen: false);
      if (!isHintDialogVisible && questionProvider.currentHint.isNotEmpty) {
        _showHintDialog(context, questionProvider.currentHint);
      }
    });
  }

  Future<void> _showHintDialog(BuildContext context, String hint) async {
    if (!isHintDialogVisible) {
      setState(() {
        isHintDialogVisible = true;
      });

      await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Hint'),
            content: Text(hint),
            actions: <Widget>[
              TextButton(
                child: const Text('Close'),
                onPressed: () {
                  setState(() {
                    isHintDialogVisible = false;
                  });
                  Navigator.of(context).pop(); // Ensure dialog is closed
                },
              ),
            ],
          );
        },
      );
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final questionProvider = Provider.of<QuestionProvider>(context, listen: false);
    if (!questionProvider.isLoading &&
        questionProvider.units.isNotEmpty &&
        questionProvider.currentTask.questionTask != null) {
      correctAnswer = questionProvider.currentTask.questionTask!.answers[
          questionProvider.currentTask.questionTask!.correctAnswer];
    }
  }

  @override
  Widget build(BuildContext context) {
    final questionProvider = Provider.of<QuestionProvider>(context);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: questionProvider.isLoading
          ? const Center(child: TemplateGameScreen(showLoadingIndicator: true))
          : buildContent(questionProvider),
    );
  }

  Future<void> handleAnswerSubmission(
      QuestionProvider questionProvider, Task currentTask) async {
    setState(() {
      answerSelected = true;
    });

    if (selectedAnswer == correctAnswer || currentTask.questionTask == null) {
      questionProvider.incrementCorrectAnswers();

      if (questionProvider.isLastUnit()) {
        await Future.delayed(const Duration(milliseconds: 500));
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => FinalScreen(
              correctAnswersCount: questionProvider.correctAnswersCount,
              totalQuestions: questionProvider.units.length,
            ),
          ),
        );
      } else {
        questionProvider.goToNextUnit();
        resetSelection(questionProvider);
        // Trigger the hint dialog manually after moving to the next question
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _showHintDialog(context, questionProvider.currentHint);
        });
      }
    } else {
      // Show wrong answer message
      await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('תשובה לא נכונה'),
            content: const Text('נסה שוב:)'),
            actions: <Widget>[
              TextButton(
                child: const Text('OK', style: TextStyle(color: Colors.brown),),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );

      // Keep the user on the same question
      resetSelection(questionProvider);
    }
  }

  Widget buildContent(QuestionProvider questionProvider) {
    if (questionProvider.units.isEmpty) {
      return Center(
        child: Text('No tasks available', style: GoogleFonts.alef()),
      );
    }

    final Task currentTask = questionProvider.currentTask;

    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/question_label.png',
            fit: BoxFit.cover,
          ),
        ),
        const TemplateGameScreen(), // Assuming this is part of the background
        Positioned(
          top: 20,
          right: 20,
          child: IconButton(
            icon: Icon(Icons.lightbulb, color: Colors.yellow[700], size: 24),
            onPressed: () {
              _showHintDialog(context, questionProvider.currentHint);
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 110),
          child: Scrollbar(
            thumbVisibility: true,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (currentTask.taskFreeTexts.isNotEmpty)
                    ...currentTask.taskFreeTexts.map(
                      (text) => Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: Center(
                          child: Text(
                            text,
                            style: const TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    ),
                  if (currentTask.mediaList.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Wrap(
                        alignment: WrapAlignment.center,
                        spacing: 8.0,
                        runSpacing: 8.0,
                        children: currentTask.mediaList
                            .map((media) => MediaWidget(media: media))
                            .toList(),
                      ),
                    ),
                  if (currentTask.questionTask != null)
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Center(
                        child: Text(
                          currentTask.questionTask!.question,
                          style: GoogleFonts.alef(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                          textDirection: TextDirection.ltr,
                        ),
                      ),
                    ),
                  if (currentTask.questionTask != null)
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: buildAnswerButtons(
                            currentTask.questionTask!.answers),
                      ),
                    ),
                  const SizedBox(height: 5),
                  // Place Submit button directly under the answer buttons
                  Center(
                    child: Opacity(
                      opacity: selectedAnswer.isNotEmpty ? 1.0 : 0.6,
                      child: buildButton(
                        key: const Key('check_answer_button'),
                        buttonText: 'Submit',
                        imagePath: 'assets/images/bottom_borad.png',
                        onPressed: () async {
                          if (selectedAnswer.isNotEmpty) {
                            await handleAnswerSubmission(
                                questionProvider, currentTask);
                          }
                        },
                        isSelected: selectedAnswer.isNotEmpty,
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          right: 20,
          child: ElevatedButton(
            onPressed: () async {
              if (questionProvider.isLastUnit()) {
                // Reset the provider state before navigating to the final screen
                questionProvider.resetGame();

                await Future.delayed(const Duration(milliseconds: 500));
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FinalScreen(
                      correctAnswersCount: questionProvider.correctAnswersCount,
                      totalQuestions: questionProvider.units.length,
                    ),
                  ),
                );
              } else {
                questionProvider.goToNextUnit();
                resetSelection(questionProvider);
                // Trigger the hint dialog manually after skipping to the next question
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _showHintDialog(context, questionProvider.currentHint);
                });
              }
            },
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              'דלג',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  void selectAnswer(String answer) {
    setState(() {
      selectedAnswer = answer;
      answerSelected = false;
    });
  }

  void resetSelection(QuestionProvider questionProvider) {
    setState(() {
      selectedAnswer = '';
      answerSelected = false;
      if (questionProvider.currentTask.questionTask != null) {
        correctAnswer = questionProvider.currentTask.questionTask!.answers[
            questionProvider.currentTask.questionTask!.correctAnswer];
      }
    });
  }

  List<Widget> buildAnswerButtons(List<String> answers) {
    return [
      for (int i = 0; i < answers.length; i += 2)
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            buildAnswerButton(answers[i], i),
            if (i + 1 < answers.length)
              buildAnswerButton(answers[i + 1], i + 1),
          ],
        ),
    ];
  }

  Widget buildButton({
    required String buttonText,
    required String imagePath,
    required VoidCallback onPressed,
    required bool isSelected,
    required Key key,
  }) {
    return InkWell(
      key: key,
      onTap: onPressed,
      child: Stack(
        children: [
          Opacity(
            opacity: isSelected ? 1.0 : 0.6,
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(imagePath),
                  fit: BoxFit.scaleDown,
                ),
              ),
              child: Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    buttonText,
                    style: GoogleFonts.alef(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildAnswerButton(String answer, int index) {
    return buildButton(
      key: Key('answer_button_$index'),
      buttonText: answer,
      imagePath: 'assets/images/button.png',
      isSelected: selectedAnswer == answer,
      onPressed: () {
        selectAnswer(answer);
      },
    );
  }
}
