import 'package:flutter/material.dart';
import 'package:flutter_player/view/widgets/CameraPage.dart';
import 'package:flutter_player/view/widgets/qr_scaner.dart';
import 'package:provider/provider.dart';
import '../../providers/task_provider.dart';


class HintDisplay extends StatelessWidget {
  final int unitIndex;

  const HintDisplay({super.key, required this.unitIndex});

  @override
  Widget build(BuildContext context) {
    final questionProvider = Provider.of<QuestionProvider>(context, listen: false);
    final unit = questionProvider.units[unitIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('Hint'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              unit.hint,
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to the QR Scanner for the location validation
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => QRScanner(
                      onScanComplete: (scannedData) {
                        _handleSecondScan(scannedData, context);
                      },
                      expectedQRCode: unit.locationDTO.qrcodePublicUrl,
                    ),
                  ),
                );
              },
              child: const Text('Scan Location QR Code'),
            ),
          ],
        ),
      ),
    );
  }

  void _handleSecondScan(String scannedData, BuildContext context) {
    final questionProvider = Provider.of<QuestionProvider>(context, listen: false);
    final unit = questionProvider.units[unitIndex];

    if (scannedData == unit.locationDTO.name) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Correct room!')),
      );

      // Navigate to the camera screen for image capture
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => CameraPage(
            unitIndex: unitIndex,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Wrong location. Try again.')),
      );
    }
  }
}
