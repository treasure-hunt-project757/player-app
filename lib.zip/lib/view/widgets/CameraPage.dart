import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:flutter_player/view/widgets/question.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;
import 'package:provider/provider.dart';

import '../../main.dart';
import '../../providers/task_provider.dart';

class CameraPage extends StatefulWidget {
  final int unitIndex;

  const CameraPage({Key? key, required this.unitIndex}) : super(key: key);

  @override
  _CameraPageState createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  bool _isUploading = false; // Track if an upload is in progress

  @override
  void initState() {
    super.initState();
    _controller = CameraController(
      cameras.first,
      ResolutionPreset.high,
    );

    _initializeControllerFuture = _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Stack(
              children: [
                CameraPreview(_controller),
                if (_isUploading)
                  Center(
                    child: Container(
                      color: Colors.black45,
                      child: const CircularProgressIndicator(), // Show loading indicator
                    ),
                  ),
              ],
            );
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
      floatingActionButton: _isUploading
          ? null // Disable the button while uploading
          : FloatingActionButton(
              onPressed: () async {
                setState(() {
                  _isUploading = true;
                });

                try {
                  await _initializeControllerFuture;

                  final image = await _controller.takePicture();
                  await _uploadAndValidatePhoto(image.path, context);
                } catch (e) {
                  // Handle camera errors here
                } finally {
                  setState(() {
                    _isUploading = false;
                  });
                }
              },
              child: const Icon(Icons.camera),
            ),
    );
  }

  Future<void> _uploadAndValidatePhoto(String filePath, BuildContext context) async {
    try {
      // Convert image to bytes
      final bytes = await _controller.takePicture().then((file) => file.readAsBytes());

      // Create a multipart request manually
      final uri = Uri.parse('https://custom-fastapi-service-tm3zus3bzq-uc.a.run.app/predict');
      final request = http.MultipartRequest('POST', uri)
        ..files.add(http.MultipartFile.fromBytes(
          'file', 
          bytes,
          filename: path.basename(filePath),
        ));

      final response = await request.send();

      if (response.statusCode == 200) {
        final responseBody = await response.stream.bytesToString();
        final jsonResponse = json.decode(responseBody);

        final objectName = Provider.of<QuestionProvider>(context, listen: false)
            .units[widget.unitIndex]
            .objectDTO
            .name;

        if (jsonResponse['predicted_object'] == objectName) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => const Question(),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Object validation failed. Try again.')),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Image upload failed. Please try again.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('An error occurred during the upload.')),
      );
    }
  }
}
