// import 'package:flutter/material.dart';
// import 'package:camera/camera.dart';
// import 'package:qr_code_scanner/qr_code_scanner.dart';

// import 'success_scan.dart';

// class QRScanner extends StatelessWidget {
//   final CameraController controller;

//   const QRScanner({super.key, required this.controller});

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
//       child: Center(
//         child: Stack(
//           alignment: Alignment.center,
//           children: [
//             AspectRatio(
//               aspectRatio: controller.value.aspectRatio,
//               child: CameraPreview(controller),
//             ),
//             QRView(
//               key: GlobalKey(),
//               onQRViewCreated: (controller) =>
//                   _onQRViewCreated(context, controller),
//               overlay: QrScannerOverlayShape(
//                 borderColor: Colors.blue,
//                 borderRadius: 20,
//                 borderLength: 10,
//                 borderWidth: 10,
//                 cutOutSize: 300,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   void _onQRViewCreated(BuildContext context, QRViewController controller) {
//     controller.scannedDataStream.listen((scanData) {
//       if (scanData.code!.isNotEmpty) {
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(
//             builder: (context) => const SuccessScan(),
//           ),
//         );
//       }
//     });
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:mobile_scanner/mobile_scanner.dart';
// import 'success_scan.dart';

// class QRScanner extends StatefulWidget {
//   const QRScanner({super.key});

//   @override
//   State<QRScanner> createState() => _QRScannerState();
// }

// class _QRScannerState extends State<QRScanner> {
//   late MobileScannerController controller;

//   @override
//   void initState() {
//     super.initState();
//     controller = MobileScannerController(
//       detectionSpeed: DetectionSpeed.noDuplicates,
//       facing: CameraFacing.back,
//     );
//   }

//   @override
//   void dispose() {
//     controller.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Padding(
//         padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
//         child: Center(
//           child: MobileScanner(
//             fit: BoxFit.contain,
//             controller: controller,
//             onDetect: (capture) {
//               final List<Barcode> barcodes = capture.barcodes;
//               if (barcodes.isNotEmpty && mounted) {
//                 controller.dispose(); // Stop scanning after the first detection
//                 Navigator.pushReplacement(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => const SuccessScan(),
//                   ),
//                 );
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class QRScanner extends StatelessWidget {
  final Function(String) onScanComplete;
  final String expectedQRCode;

  const QRScanner({super.key, required this.onScanComplete, required this.expectedQRCode});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
        child: Center(
          child: MobileScanner(
            fit: BoxFit.contain,
            onDetect: (capture) {
              final List<Barcode> barcodes = capture.barcodes;
              if (barcodes.isNotEmpty) {
                final scannedData = barcodes.first.rawValue ?? '';
                if (scannedData.isNotEmpty) {
                  onScanComplete(scannedData);
                }
              }
            },
          ),
        ),
      ),
    );
  }
}
