import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import '../../providers/task_provider.dart';
import './HintDisplay.dart';

class ObjectFinder extends StatelessWidget {
  const ObjectFinder({super.key});

  Future<void> _handleBarcode(String barcode, BuildContext context) async {
    final decodedBarcode = utf8.decode(barcode.runes.toList());
    final questionProvider = Provider.of<QuestionProvider>(context, listen: false);

    // Fetch tasks using the QR code's URL
    await questionProvider.fetchTasksFromQRCode(decodedBarcode);

    // Navigate to the hint screen for the first unit
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const HintDisplay(unitIndex: 0), // Pass the first unit index
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
      child: Center(
        child: MobileScanner(
          fit: BoxFit.contain,
          onDetect: (capture) {
            final List<Barcode> barcodes = capture.barcodes;
            if (barcodes.isNotEmpty) {
              final barcode = barcodes.first.rawValue ?? '';
              if (barcode.isNotEmpty) {
                _handleBarcode(barcode, context);
              }
            }
          },
        ),
      ),
    );
  }
}
