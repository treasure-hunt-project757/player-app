import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/task_model.dart';

class ApiService {
  static Future<Game> fetchGameData(String url) async {
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final decodedResponseBody = utf8.decode(response.bodyBytes);
      final data = jsonDecode(decodedResponseBody);
      return Game.fromJson(data);
    } else {
      throw Exception('Failed to load game data');
    }
  }
}
